#ifndef GAME_COMPONENTS_H_
#define GAME_COMPONENTS_H_

namespace GAME
{
	///*** Tags ***///
	

	///*** Components ***///
	

}// namespace GAME
#endif // !GAME_COMPONENTS_H_