#include "GameComponents.h"
#include "../../entt-3.13.1/single_include/entt/entt.hpp"
#include "..\CCL.h"	
#include "../DRAW/DrawComponents.h"

namespace GAME {

	void UpdateGameManager(entt::registry& registry, entt::entity entity){

        auto view = registry.view<GAME::Transform, DRAW::MeshCollection>();

        for (auto entity : view)
        {
            auto& transform = view.get<GAME::Transform>(entity);
            auto& meshCollection = view.get<DRAW::MeshCollection>(entity);

            for (auto meshEntity : meshCollection.meshEntities)
            {
                if (registry.all_of<DRAW::GPUInstance>(meshEntity))
                {
                    auto& gpuInstance = registry.get<DRAW::GPUInstance>(meshEntity);

                    gpuInstance.transform = transform.matrix;
                }
            }
        }

        auto playerView = registry.view<GAME::Player, GAME::Transform>();
        for (auto player : playerView)
        {
            registry.patch<GAME::Player>(player);
        }
	}

	CONNECT_COMPONENT_LOGIC() {
		registry.on_update<GameManager>().connect<&UpdateGameManager>();
	}

}