#include "GameComponents.h"
#include "../DRAW/DrawComponents.h"
#include "../UTIL/Utilities.h"
#include "..\CCL.h"	

namespace GAME {

	void SpawnBullet(entt::registry& registry, std::shared_ptr<GameConfig>& config, Transform transform)
	{
		auto bullet = registry.create();
		registry.emplace<GAME::Transform>(bullet, transform);
		registry.emplace<GAME::Bullet>(bullet);
		auto modelManager = registry.ctx().get<DRAW::ModelManager>();
		auto modelName = config->at("Bullet").at("model").as<std::string>();
		auto& mesh = modelManager.modelMap.find(modelName);

		if (mesh == modelManager.modelMap.end())
		{
			std::cout << "Error: No mesh collection found for " << &modelName << "." << std::endl;
		}

		auto& meshCollection = mesh->second.meshEntities;

		auto& gameMeshCollection = registry.emplace<DRAW::MeshCollection>(bullet);

		for (auto meshEntity : meshCollection)
		{

			const auto& originalGeometryData = registry.get<DRAW::GeometryData>(meshEntity);
			auto& originalGPUInstance = registry.get<DRAW::GPUInstance>(meshEntity);
			originalGPUInstance.transform = transform.matrix;

			entt::entity newMeshEntity = registry.create();

			registry.emplace<DRAW::GeometryData>(newMeshEntity, originalGeometryData);
			registry.emplace<DRAW::GPUInstance>(newMeshEntity, originalGPUInstance);

			gameMeshCollection.meshEntities.push_back(newMeshEntity);
		}

		if (!meshCollection.empty())
		{
			auto& gpuInstance = registry.get<DRAW::GPUInstance>(meshCollection.front());
			gpuInstance.transform = transform.matrix;
		}

	}

	void UpdatePlayer(entt::registry& registry, entt::entity entity)
	{
		auto& transform = registry.get<GAME::Transform>(entity);
		auto& config = registry.ctx().get<UTIL::Config>().gameConfig;
		auto& input = registry.ctx().get<UTIL::Input>();
		auto& deltaTime = registry.ctx().get<UTIL::DeltaTime>().dtSec;

		float speed;
		float firerate;
		try {
			speed = config->at("Player").at("speed").as<float>();
			firerate = config->at("Player").at("firerate").as<float>();
		}
		catch (...) {
			speed = 8.0f;
			firerate = 0.5f;
		}

		GW::MATH::GVECTORF moveVector = { 0.0f, 0.0f, 0.0f };

		float w, a, s, d;
		input.immediateInput.GetState(G_KEY_W, w);
		input.immediateInput.GetState(G_KEY_S, s);
		input.immediateInput.GetState(G_KEY_A, a);
		input.immediateInput.GetState(G_KEY_D, d);

		if (w) moveVector.z += 1.0f;
		if (s) moveVector.z -= 1.0f;
		if (a) moveVector.x -= 1.0f;
		if (d) moveVector.x += 1.0f;


		GW::MATH::GVector::NormalizeF(moveVector, moveVector);

		GW::MATH::GVECTORF scaledMove;
		GW::MATH::GVector::ScaleF(moveVector, speed * deltaTime, scaledMove);

		GW::MATH::GMatrix::TranslateLocalF(transform.matrix, scaledMove, transform.matrix);

		if (registry.all_of<Firing>(entity)) {
			auto& firing = registry.get<Firing>(entity);
			firing.cooldown -= deltaTime;
			if (firing.cooldown <= 0.0f) {
				registry.remove<Firing>(entity);
			}
		}

		else {
			float left, right, up, down;
			input.immediateInput.GetState(G_KEY_LEFT, left);
			input.immediateInput.GetState(G_KEY_RIGHT, right);
			input.immediateInput.GetState(G_KEY_UP, up);
			input.immediateInput.GetState(G_KEY_DOWN, down);

			if (left || right || down || up)
			{
				SpawnBullet(registry, config, transform);
				registry.emplace<Firing>(entity, Firing{ firerate });
			}
		}

	}

	CONNECT_COMPONENT_LOGIC() {

		registry.on_update<Player>().connect<&UpdatePlayer>();
	}

}